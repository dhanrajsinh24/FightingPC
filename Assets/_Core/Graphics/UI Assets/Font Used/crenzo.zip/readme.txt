Free for personal and desktop commercial use.

for more font collection please click this link : https://www.youworkforthem.com/designer/1410/reza-rasenda?aff=863

ANY DONATION ARE VERY APPRECIATED.

dont forget to follow our social media for monthly freebie font:

instagram :https://www.instagram.com/zeafonts/

behance : https://www.behance.net/zealab

thank you